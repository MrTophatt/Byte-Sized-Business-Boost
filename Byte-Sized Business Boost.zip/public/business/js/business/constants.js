const REVIEW_STAR_BUCKETS = [5, 4, 3, 2, 1];
const DAY_KEYS = [
    "sunday",
    "monday",
    "tuesday",
    "wednesday",
    "thursday",
    "friday",
    "saturday"
];

window.businessDetailConstants = {
    REVIEW_STAR_BUCKETS,
    DAY_KEYS
};